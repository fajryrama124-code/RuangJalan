# Ruang Jalan — Android APK

Project Android WebView untuk website Ruang Jalan.

## Build APK dengan GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini ke repository.
3. Buka tab **Actions**.
4. Pilih **Build Ruang Jalan APK**.
5. Jika workflow belum berjalan otomatis, pilih **Run workflow**.
6. Tunggu sampai job selesai dengan status hijau.
7. Buka hasil workflow dan download artifact **RuangJalan-debug-apk**.
8. Extract artifact ZIP untuk mendapatkan `app-debug.apk`.
9. Install APK di HP Android.

Workflow juga akan berjalan otomatis setiap kali ada push ke branch `main` atau `master`.

## Isi utama

- `app/` — aplikasi Android WebView dan website Ruang Jalan.
- `.github/workflows/build-apk.yml` — konfigurasi build APK otomatis di GitHub Actions.
