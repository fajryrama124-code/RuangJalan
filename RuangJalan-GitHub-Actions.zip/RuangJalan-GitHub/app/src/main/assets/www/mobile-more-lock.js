(() => {
  const moreSelector = '.mobile-more-layer';
  const sidebarSelector = '.sidebar.mobile-open';
  let locked = false;
  let saved = null;

  function lockPage() {
    if (!locked) {
      locked = true;
      const y = window.scrollY || window.pageYOffset || 0;
      saved = {
        y,
        htmlOverflow: document.documentElement.style.overflow,
        body: {
          position: document.body.style.position,
          top: document.body.style.top,
          left: document.body.style.left,
          right: document.body.style.right,
          width: document.body.style.width,
          overflow: document.body.style.overflow
        }
      };
      Object.assign(document.body.style, {
        position: 'fixed',
        top: `-${y}px`,
        left: '0',
        right: '0',
        width: '100%',
        overflow: 'hidden'
      });
      document.documentElement.style.overflow = 'hidden';
      document.documentElement.classList.add('mobile-page-locked');
      document.body.classList.add('mobile-page-locked');
    }

    const moreOpen = !!document.querySelector(moreSelector);
    document.documentElement.classList.toggle('mobile-more-open', moreOpen);
    document.body.classList.toggle('mobile-more-open', moreOpen);
  }

  function unlockPage() {
    if (!locked) return;
    locked = false;
    document.documentElement.style.overflow = saved.htmlOverflow;
    document.documentElement.classList.remove('mobile-page-locked', 'mobile-more-open');
    document.body.classList.remove('mobile-page-locked', 'mobile-more-open');
    Object.assign(document.body.style, saved.body);
    window.scrollTo(0, saved.y);
    saved = null;
  }

  function syncLayers() {
    const more = document.querySelector(moreSelector);
    const sidebarOpen = window.matchMedia('(max-width: 760px)').matches &&
      document.querySelector(sidebarSelector);

    document.body.classList.toggle('mobile-nav-open', !!sidebarOpen);
    if (more || sidebarOpen) lockPage();
    else unlockPage();
    

    const modalRoot = document.getElementById('modalRoot');
    const modalOpen = !!modalRoot?.querySelector('.modal');
    if (modalRoot) {
      modalRoot.style.position = modalOpen ? 'relative' : '';
      modalRoot.style.zIndex = modalOpen ? '2147483647' : '';
    }

    if (more) {
      more.style.position = 'fixed';
      more.style.inset = '0';
      more.style.zIndex = modalOpen ? '2147483646' : '2147483647';
      more.style.pointerEvents = 'auto';
    }
  }

  function blockBackgroundEvent(event) {
    const more = document.querySelector(moreSelector);
    const sidebarOpen = window.matchMedia('(max-width: 760px)').matches &&
      document.querySelector(sidebarSelector);
    if (!more && !sidebarOpen) return;

    const target = event.target;
    const element = target instanceof Element ? target : null;
    const inMore = !!(more && element?.closest('.mobile-more-sheet'));
    const onMoreBackdrop = !!(more && element?.closest('.mobile-more-backdrop'));
    const inSidebar = !!(sidebarOpen && element?.closest('#sidebar'));
    const onMenuButton = !!(sidebarOpen && element?.closest('#mobileMenu'));
    const inModal = !!element?.closest('#modalRoot .modal');

    if (inMore || inSidebar || onMenuButton || inModal) return;

    // With the sidebar open, block every interaction behind it; keep the sidebar usable.
    if (!more && sidebarOpen) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }

    // Let the menu backdrop close its panel, but never pass scroll gestures through it.
    if (onMoreBackdrop && ['click', 'pointerdown', 'pointerup'].includes(event.type)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  ['click', 'pointerdown', 'pointerup', 'touchstart', 'touchmove', 'wheel', 'keydown'].forEach(type => {
    document.addEventListener(type, blockBackgroundEvent, { capture: true, passive: false });
  });

  new MutationObserver(syncLayers).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class'],
    childList: true,
    subtree: true
  });
  window.addEventListener('resize', syncLayers);
  syncLayers();
})();
